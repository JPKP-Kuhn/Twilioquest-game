# TwilioQuest Launcher

This application provides a runtime and updater for the TwilioQuest game/app.

## Local development

```
npm install
npm start
```

## Packaging for distribution

This application should be updated infrequently - only when it is necessary to patch Chromium or Electron.

TODO - instructions for packaging
