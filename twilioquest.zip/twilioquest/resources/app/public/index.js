"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _App = _interopRequireDefault(require("./app/App"));

ReactDOM.render(React.createElement(_App["default"], null), document.getElementById('app'));
//# sourceMappingURL=index.js.map