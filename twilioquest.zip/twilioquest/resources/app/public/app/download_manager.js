"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs2/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _promise = _interopRequireDefault(require("@babel/runtime-corejs2/core-js/promise"));

var _regenerator = _interopRequireDefault(require("@babel/runtime-corejs2/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/createClass"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/inherits"));

var _events = _interopRequireDefault(require("events"));

var _path = _interopRequireDefault(require("path"));

var _electron = require("electron");

var _promise2 = _interopRequireDefault(require("md5-file/promise"));

var _tar = _interopRequireDefault(require("tar"));

var jetpack = _interopRequireWildcard(require("fs-jetpack"));

var _tq_firebase = require("./tq_firebase");

var versionManager = _interopRequireWildcard(require("./version_manager"));

// Get path to app data directory
var appDataPath = _path["default"].resolve(_electron.remote.app.getPath('appData'), 'TwilioQuest'); // Per platform, downloaded tarballs will have one of three names


var tarballFileName = '';
var tarFileName = '';

switch (process.platform) {
  case 'darwin':
    tarballFileName = 'mac.tgz';
    tarFileName = 'mac.tar';
    break;

  case 'win32':
    tarballFileName = 'windows.tgz';
    tarFileName = 'windows.tar';
    break;

  default:
    tarballFileName = 'linux.tgz';
    tarFileName = 'linux.tar';
    break;
} // Download manager states


var STATUS = {
  INIT: 'initializing',
  DOWNLOADING: 'downloading',
  VALIDATING: 'validating',
  EXTRACTING: 'extracting',
  OFFLINE: 'offline',
  ERROR: 'error',
  READY: 'ready'
}; // Feedback UI strings

var MESSAGES = {};
MESSAGES[STATUS.INIT] = "Initializing...";
MESSAGES[STATUS.ERROR] = "Error downloading version - restart the launcher to retry.";
MESSAGES.OFFLINE = "Can't download release version when offline.";
MESSAGES[STATUS.VALIDATING] = "Validating release...";
MESSAGES[STATUS.EXTRACTING] = "Getting things ready, one moment...";
MESSAGES[STATUS.READY] = "TwilioQuest is ready for launch!";

var DownloadManager =
/*#__PURE__*/
function (_EventEmitter) {
  (0, _inherits2["default"])(DownloadManager, _EventEmitter);

  // Set up from configured channel state
  function DownloadManager(channelState) {
    var _this;

    (0, _classCallCheck2["default"])(this, DownloadManager);
    _this = (0, _possibleConstructorReturn2["default"])(this, (0, _getPrototypeOf2["default"])(DownloadManager).call(this));
    _this.status = STATUS.INIT;
    _this.lastStatusUpdate = MESSAGES[STATUS.INIT];
    _this.channelState = channelState; // Set up necessary information for download from channel/release info

    _this.channelName = channelState.currentChannel.name;
    _this.releaseName = channelState.currentRelease.name;
    _this.releaseId = channelState.currentRelease.id;
    _this.checksum = channelState.currentRelease.checksums[tarballFileName]; // Set up necessary paths to download and extract the requested release

    _this.releasesPath = _path["default"].resolve(appDataPath, 'releases');
    _this.channelPath = _path["default"].resolve(_this.releasesPath, _this.channelName);
    _this.releasePath = _this.createReleasePath(_this.releaseName);
    _this.bundlePath = _path["default"].resolve(_this.releasePath, 'public');
    _this.donePath = _path["default"].resolve(_this.bundlePath, '.done');
    _this.htmlPath = _path["default"].resolve(_this.bundlePath, 'index.html');
    _this.tarballFilePath = _path["default"].resolve(_this.releasePath, tarballFileName);
    _this.tarFilePath = _path["default"].resolve(_this.releasePath, tarFileName); // "Stable" is a channel used for blessed builds of master (default in UI)

    var releaseBranch = _this.channelName === 'stable' ? 'master' : _this.channelName; // Set up a cloud storage path ref

    _this.releaseRef = _tq_firebase.storage.ref("releases/".concat(releaseBranch, "/").concat(_this.releaseName)); // Set up IPC event listeners which will monitor for download progress
    // Display progress events

    _electron.ipcRenderer.on('downloadProgress', function (event, payload) {
      if (payload.id !== _this.releaseId) {
        return;
      }

      var p = Math.round(payload.progress * 100);

      _this.setStatus(STATUS.DOWNLOADING, "Downloading ".concat(_this.releaseName, "... ").concat(p, "%"));
    }); // After download is complete, validate and extract package


    _electron.ipcRenderer.on('downloadSuccess', function (event, payload) {
      if (payload.id !== _this.releaseId) {
        return;
      }

      _this.validateAndExtract();
    }); // Respond to download errors


    _electron.ipcRenderer.on('downloadError', function (event, payload) {
      if (payload.id !== _this.releaseId) {
        return;
      }

      console.log("Error downloading ".concat(_this.channelName, " ").concat(_this.releaseName, ":"));
      console.log(payload.error);

      _this.setStatus(STATUS.ERROR, "Couldn't download version ".concat(_this.releaseName));
    }); // Do an initial download when created


    _this.doDownload();

    return _this;
  }

  (0, _createClass2["default"])(DownloadManager, [{
    key: "createReleasePath",
    value: function createReleasePath(releaseName) {
      return this.releasePath = _path["default"].resolve(this.channelPath, releaseName);
    } // Execute required download steps and send updates as necessary

    /*
      Overall Workflow:
      1.) Check if we've already downloaded the tarball file
      1.5) If not, download tarball
      2.) If version is already extracted, emit ready, if not, extract
      3.) Validate tarball's checksum
      4.) Extract tarball to folder
      5.) Remove old downloaded game versions - if this fails it will not delete new version
      6.) Emit ready event
      7.) TODO: Monitor extracted directory for changes?
    */

  }, {
    key: "doDownload",
    value: function doDownload() {
      var _this2 = this;

      (function () {
        var _ref = (0, _asyncToGenerator2["default"])(
        /*#__PURE__*/
        _regenerator["default"].mark(function _callee(_) {
          var tarballExists, child, downloadUrl;
          return _regenerator["default"].wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return jetpack.existsAsync(_this2.tarballFilePath);

                case 2:
                  tarballExists = _context.sent;

                  if (tarballExists) {
                    _context.next = 23;
                    break;
                  }

                  if (window.navigator.onLine) {
                    _context.next = 6;
                    break;
                  }

                  return _context.abrupt("return", _this2.setStatus(STATUS.ERROR, MESSAGES.OFFLINE));

                case 6:
                  _context.prev = 6;
                  _context.next = 9;
                  return jetpack.dirAsync(_this2.releasePath);

                case 9:
                  // Get goole cloud download link
                  child = _this2.releaseRef.child(tarballFileName);
                  _context.next = 12;
                  return child.getDownloadURL();

                case 12:
                  downloadUrl = _context.sent;

                  // Use IPC to initiate a download - progress events declared in the
                  // constructor will monitor progress
                  _electron.ipcRenderer.send('downloadFile', {
                    url: downloadUrl,
                    directory: _this2.releasePath,
                    filename: tarballFileName,
                    id: _this2.releaseId
                  });

                  _context.next = 21;
                  break;

                case 16:
                  _context.prev = 16;
                  _context.t0 = _context["catch"](6);
                  console.log("Error downloading ".concat(_this2.channelName, " ").concat(_this2.releaseName, ":"));
                  console.log(_context.t0);

                  _this2.setStatus(STATUS.ERROR, "Couldn't download version ".concat(_this2.releaseName));

                case 21:
                  _context.next = 24;
                  break;

                case 23:
                  // If we already have it, skip to the validation and extraction step
                  _this2.validateAndExtract();

                case 24:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, null, [[6, 16]]);
        }));

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      })()();
    } // Validate and extract downloaded tarball file

  }, {
    key: "validateAndExtract",
    value: function () {
      var _validateAndExtract = (0, _asyncToGenerator2["default"])(
      /*#__PURE__*/
      _regenerator["default"].mark(function _callee3() {
        var _this3 = this;

        var failWithError, bundleExists, doneFileExists, exists, hash, fileNo, fileTotal;
        return _regenerator["default"].wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                this.setStatus(STATUS.VALIDATING);

                failWithError =
                /*#__PURE__*/
                function () {
                  var _ref2 = (0, _asyncToGenerator2["default"])(
                  /*#__PURE__*/
                  _regenerator["default"].mark(function _callee2(e) {
                    var m;
                    return _regenerator["default"].wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            m = "Couldn't launch ".concat(_this3.releaseName, " (").concat(_this3.channelName, ").");
                            console.log(m, e);

                            _this3.setStatus(STATUS.ERROR, m); // If the download couldn't be validated, the release is probably corrupt
                            // Remove the release folder so it can be re-created from fresh downloads


                            _context2.prev = 3;
                            _context2.next = 6;
                            return jetpack.removeAsync(_this3.releasePath);

                          case 6:
                            _context2.next = 13;
                            break;

                          case 8:
                            _context2.prev = 8;
                            _context2.t0 = _context2["catch"](3);
                            console.log('Error removing release folder');
                            console.log(_context2.t0);

                            _this3.setStatus(STATUS.ERROR);

                          case 13:
                          case "end":
                            return _context2.stop();
                        }
                      }
                    }, _callee2, null, [[3, 8]]);
                  }));

                  return function failWithError(_x2) {
                    return _ref2.apply(this, arguments);
                  };
                }();

                _context3.prev = 2;
                _context3.next = 5;
                return jetpack.existsAsync(this.bundlePath);

              case 5:
                bundleExists = _context3.sent;
                _context3.next = 8;
                return jetpack.existsAsync(this.donePath);

              case 8:
                doneFileExists = _context3.sent;

                if (!(bundleExists && doneFileExists)) {
                  _context3.next = 11;
                  break;
                }

                return _context3.abrupt("return", this.setStatus(STATUS.READY));

              case 11:
                _context3.next = 13;
                return jetpack.existsAsync(this.tarballFilePath);

              case 13:
                exists = _context3.sent;

                if (exists) {
                  _context3.next = 16;
                  break;
                }

                throw "tarball package does not exist";

              case 16:
                _context3.next = 18;
                return (0, _promise2["default"])(this.tarballFilePath);

              case 18:
                hash = _context3.sent;
                console.log("Checksum for ".concat(tarballFileName, ":"), hash);

                if (!(hash !== this.checksum)) {
                  _context3.next = 22;
                  break;
                }

                throw "Checksum from server and downloaded package don't match.";

              case 22:
                // Update user-facing status
                this.setStatus(STATUS.EXTRACTING); // Ensure previous bundle folder does not exist, then recreate

                _context3.next = 25;
                return jetpack.removeAsync(this.bundlePath);

              case 25:
                _context3.next = 27;
                return jetpack.dirAsync(this.bundlePath);

              case 27:
                // use tar to extract
                fileNo = 0, fileTotal = 0; // Get number of file entries

                _context3.next = 30;
                return _tar["default"].t({
                  file: this.tarballFilePath,
                  cwd: this.releasePath,
                  onentry: function onentry(_) {
                    return fileTotal++;
                  }
                });

              case 30:
                _context3.next = 32;
                return _tar["default"].x({
                  file: this.tarballFilePath,
                  cwd: this.releasePath,
                  onentry: function onentry(entry) {
                    return _this3.setStatus(STATUS.EXTRACTING, "Extracting: ".concat(Math.floor(fileNo++ / fileTotal * 100), "%"));
                  }
                });

              case 32:
                _context3.next = 34;
                return this.removeOldVersions();

              case 34:
                _context3.next = 36;
                return jetpack.writeAsync(this.donePath, 'extraction completed!');

              case 36:
                // If we got to this point, we're gtg!
                this.setStatus(STATUS.READY);
                _context3.next = 42;
                break;

              case 39:
                _context3.prev = 39;
                _context3.t0 = _context3["catch"](2);
                failWithError(_context3.t0);

              case 42:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[2, 39]]);
      }));

      function validateAndExtract() {
        return _validateAndExtract.apply(this, arguments);
      }

      return validateAndExtract;
    }()
  }, {
    key: "removeOldVersions",
    value: function () {
      var _removeOldVersions = (0, _asyncToGenerator2["default"])(
      /*#__PURE__*/
      _regenerator["default"].mark(function _callee4() {
        var _this4 = this;

        var releaseDirExists, localReleaseNames, remoteReleaseNames, remoteReleases, isLocalReleaseOnRemote, oldReleases, removeOldReleasePromises;
        return _regenerator["default"].wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return jetpack.existsAsync(this.channelPath);

              case 2:
                releaseDirExists = _context4.sent;

                if (releaseDirExists) {
                  _context4.next = 6;
                  break;
                }

                this.logError('Release directory does not exist!');
                return _context4.abrupt("return");

              case 6:
                _context4.prev = 6;
                _context4.next = 9;
                return jetpack.listAsync(this.channelPath);

              case 9:
                localReleaseNames = _context4.sent;
                _context4.next = 16;
                break;

              case 12:
                _context4.prev = 12;
                _context4.t0 = _context4["catch"](6);
                this.logError('Error listing old downloaded versions!', _context4.t0);
                return _context4.abrupt("return");

              case 16:
                _context4.prev = 16;
                _context4.next = 19;
                return versionManager.fetchReleases(this.channelName);

              case 19:
                remoteReleases = _context4.sent;
                remoteReleaseNames = remoteReleases.map(function (release) {
                  return release.name;
                });
                _context4.next = 27;
                break;

              case 23:
                _context4.prev = 23;
                _context4.t1 = _context4["catch"](16);
                this.logError('Error accessing remote version list!', _context4.t1);
                return _context4.abrupt("return");

              case 27:
                isLocalReleaseOnRemote = function isLocalReleaseOnRemote(localName) {
                  return !remoteReleaseNames.includes(localName);
                };

                oldReleases = localReleaseNames.filter(isLocalReleaseOnRemote);
                _context4.prev = 29;
                removeOldReleasePromises = oldReleases.map(function (oldRelease) {
                  return jetpack.removeAsync(_this4.createReleasePath(oldRelease));
                });
                _context4.next = 33;
                return _promise["default"].all(removeOldReleasePromises);

              case 33:
                _context4.next = 39;
                break;

              case 35:
                _context4.prev = 35;
                _context4.t2 = _context4["catch"](29);
                this.logError('Error removing old verions', _context4.t2);
                return _context4.abrupt("return");

              case 39:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[6, 12], [16, 23], [29, 35]]);
      }));

      function removeOldVersions() {
        return _removeOldVersions.apply(this, arguments);
      }

      return removeOldVersions;
    }()
  }, {
    key: "logError",
    value: function logError(message, error) {
      if (message) {
        console.log(message);
      }

      if (error) {
        console.log(error);
      }

      this.setStatus(STATUS.ERROR);
    } // Set a new status and emit an update

  }, {
    key: "setStatus",
    value: function setStatus(type, message) {
      this.status = type;
      this.lastStatusUpdate = message || MESSAGES[type];
      this.emit('statusChange', {
        type: type,
        message: this.lastStatusUpdate
      });
    }
  }]);
  return DownloadManager;
}(_events["default"]);

var _default = DownloadManager;
exports["default"] = _default;
//# sourceMappingURL=download_manager.js.map