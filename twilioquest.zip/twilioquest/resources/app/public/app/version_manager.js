"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.hasNewLauncherVersion = hasNewLauncherVersion;
exports.fetchChannels = fetchChannels;
exports.fetchReleases = fetchReleases;

var _regenerator = _interopRequireDefault(require("@babel/runtime-corejs2/regenerator"));

var _stringify = _interopRequireDefault(require("@babel/runtime-corejs2/core-js/json/stringify"));

var _promise = _interopRequireDefault(require("@babel/runtime-corejs2/core-js/promise"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/asyncToGenerator"));

var _tq_firebase = require("./tq_firebase");

var app = require('electron').remote.app;

var _window = window,
    localStorage = _window.localStorage;
var LS_CHANNELS = 'releaseChannels'; // Check if there is a newer version of the launcher application available

function hasNewLauncherVersion() {
  return _hasNewLauncherVersion.apply(this, arguments);
}

function _hasNewLauncherVersion() {
  _hasNewLauncherVersion = (0, _asyncToGenerator2["default"])(
  /*#__PURE__*/
  _regenerator["default"].mark(function _callee3() {
    var version, doc, latest;
    return _regenerator["default"].wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            version = app.getVersion().split('.')[0];
            _context3.next = 3;
            return _tq_firebase.db.collection('launcherVersion').doc('latest').get();

          case 3:
            doc = _context3.sent;
            latest = doc.data().version;
            return _context3.abrupt("return", version !== latest);

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _hasNewLauncherVersion.apply(this, arguments);
}

function fetchChannels() {
  function doFetch(_x, _x2) {
    return _doFetch.apply(this, arguments);
  }

  function _doFetch() {
    _doFetch = (0, _asyncToGenerator2["default"])(
    /*#__PURE__*/
    _regenerator["default"].mark(function _callee(resolve, reject) {
      var channelJson, _channelList, channelList, snapshot;

      return _regenerator["default"].wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;

              if (window.navigator.onLine) {
                _context.next = 9;
                break;
              }

              channelJson = localStorage.getItem(LS_CHANNELS);

              if (!channelJson) {
                _context.next = 8;
                break;
              }

              _channelList = JSON.parse(channelJson);
              return _context.abrupt("return", resolve(_channelList));

            case 8:
              return _context.abrupt("return", reject(new Error("No offline channel list available.")));

            case 9:
              // Grab latest channel list from Firebase
              channelList = [];
              _context.next = 12;
              return _tq_firebase.db.collection('releaseChannels').orderBy('priority').get();

            case 12:
              snapshot = _context.sent;
              snapshot.forEach(function (doc) {
                var docData = doc.data();
                docData.id = doc.id;
                channelList.push(docData);
              }); // Store the most recent result in localStorage to use as a fallback
              // when offline, IFF we successfully actually got something from
              // Firebase

              if (channelList && channelList.length > 0) {
                localStorage.setItem(LS_CHANNELS, (0, _stringify["default"])(channelList));
              }

              resolve(channelList);
              _context.next = 22;
              break;

            case 18:
              _context.prev = 18;
              _context.t0 = _context["catch"](0);
              console.log("Error fetching channel list", _context.t0);
              reject(_context.t0);

            case 22:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 18]]);
    }));
    return _doFetch.apply(this, arguments);
  }

  return new _promise["default"](function (resolve, reject) {
    doFetch(resolve, reject);
  });
}

function fetchReleases(channelName) {
  function doFetch(_x3, _x4) {
    return _doFetch2.apply(this, arguments);
  }

  function _doFetch2() {
    _doFetch2 = (0, _asyncToGenerator2["default"])(
    /*#__PURE__*/
    _regenerator["default"].mark(function _callee2(resolve, reject) {
      var LS_RELEASE, releaseJson, releasesData, releaseList, snapshot;
      return _regenerator["default"].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              LS_RELEASE = "releases-".concat(channelName); // When offline, try to load the release list from localStorage

              if (window.navigator.onLine) {
                _context2.next = 10;
                break;
              }

              releaseJson = localStorage.getItem(LS_RELEASE);

              if (!releaseJson) {
                _context2.next = 9;
                break;
              }

              releasesData = JSON.parse(releaseJson);
              return _context2.abrupt("return", resolve(releasesData));

            case 9:
              return _context2.abrupt("return", reject(new Error("No offline release list available.")));

            case 10:
              // Grab the last several releases 
              releaseList = [];
              _context2.next = 13;
              return _tq_firebase.db.collection('releases').where('channelName', '==', channelName).orderBy('createdAt', 'desc').orderBy('name', 'desc').get();

            case 13:
              snapshot = _context2.sent;
              snapshot.forEach(function (doc) {
                // Massage release data into the format we want
                var docData = {
                  id: doc.id,
                  createdAt: doc.get('createdAt').toDate(),
                  name: doc.get('name'),
                  checksums: doc.get('checksums'),
                  channelName: channelName
                };
                releaseList.push(docData);
              }); // Store the most recent result in localStorage to use as a fallback
              // when offline, IFF we successfully actually got something from
              // Firebase

              if (releaseList && releaseList.length > 0) {
                localStorage.setItem(LS_RELEASE, (0, _stringify["default"])(releaseList));
              }

              resolve(releaseList);
              _context2.next = 23;
              break;

            case 19:
              _context2.prev = 19;
              _context2.t0 = _context2["catch"](0);
              console.log("Error fetching release list", _context2.t0);
              reject(_context2.t0);

            case 23:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 19]]);
    }));
    return _doFetch2.apply(this, arguments);
  }

  return new _promise["default"](function (resolve, reject) {
    doFetch(resolve, reject);
  });
}
//# sourceMappingURL=version_manager.js.map