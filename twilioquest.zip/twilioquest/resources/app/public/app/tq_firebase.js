"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.storage = exports.db = void 0;

var _config = _interopRequireDefault(require("./config"));

// Initialize Firebase connection (firebase is window-scoped)
firebase.initializeApp(_config["default"].firebaseConfig);
var db = firebase.firestore();
exports.db = db;
var storage = firebase.storage();
exports.storage = storage;
//# sourceMappingURL=tq_firebase.js.map