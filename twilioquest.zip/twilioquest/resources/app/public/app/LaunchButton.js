"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/slicedToArray"));

var _download_manager = _interopRequireDefault(require("./download_manager"));

var _require$remote = require('electron').remote,
    BrowserWindow = _require$remote.BrowserWindow,
    getCurrentWindow = _require$remote.getCurrentWindow; // React hooks


var _React = React,
    useState = _React.useState,
    useEffect = _React.useEffect; // Maintain in-memory references to download managers for different release
// versions

var dlManagers = {};

function LaunchButton(props) {
  var _useState = useState(false),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      canLaunch = _useState2[0],
      setCanLaunch = _useState2[1];

  var _useState3 = useState(false),
      _useState4 = (0, _slicedToArray2["default"])(_useState3, 2),
      showRetry = _useState4[0],
      setShowRetry = _useState4[1]; // Internal helper to get current download manager for selected release
  // (can be null)


  function getCurrentDownloadManager() {
    if (props.channelState && props.channelState.currentRelease) {
      var releaseId = props.channelState.currentRelease.id;
      return dlManagers[releaseId];
    } else {
      return null;
    }
  } // Execute async setup in the side-effect inducing hook


  useEffect(function () {
    // if we haven't received channel state, we can't initialize
    if (!props.channelState) {
      return;
    } // If current release is null, it could be a condition where a channel has
    // no current releases (like release candidates)


    if (!props.channelState.currentRelease) {
      props.onLaunchStatusUpdate({
        type: 'error',
        message: "No releases available."
      });
      setCanLaunch(false);
      setShowRetry(false);
      return;
    } // Check if a download manager has been created for the given release ID
    // Create one if necessary


    var releaseId = props.channelState.currentRelease.id;
    var dm = dlManagers[releaseId];

    if (!dm) {
      dm = new _download_manager["default"](props.channelState);
      dlManagers[releaseId] = dm;
      console.log("Download manager for ".concat(releaseId, " created."));
    } // Update launch UI with current download state


    props.onLaunchStatusUpdate({
      type: dm.status,
      message: dm.lastStatusUpdate
    }); // If the download manager is already in a ready state, we can launch
    // Otherwise, we need to initiate a download/validate process

    switch (dm.status) {
      case 'ready':
        setCanLaunch(true);
        setShowRetry(false);
        break;

      case 'error':
        // Enable a retry option in the UI
        setCanLaunch(false);
        setShowRetry(true);
        break;

      default:
        // no-op - all other states indicate a download/validation is already
        // in progress or has failed
        break;
    } // Handler function to react to download status


    function handleDownloadStatus(e) {
      // The ready event indicates the selected game version is ready to launch
      setCanLaunch(e.type === 'ready'); // Send status message back up to parent

      props.onLaunchStatusUpdate(e);
    }

    dm.on('statusChange', handleDownloadStatus); // Remove subscription for cleanup

    return function cleanup() {
      dm.removeListener('statusChange', handleDownloadStatus);
    };
  }); // Launch the selected version, if possible

  function launch() {
    // Shouldn't happen, but bail if launch status is not okay
    if (!canLaunch) {
      return;
    } // Create and manage an electron browser window with the unzipped game


    var dm = getCurrentDownloadManager(); // Launch new browser window

    var bw = new BrowserWindow({
      title: 'TwilioQuest',
      backgroundColor: '#232323',
      height: 800,
      width: 1280,
      minWidth: 1024,
      minHeight: 576,
      show: false,
      webPreferences: {
        nodeIntegration: true
      }
    });
    bw.loadFile(dm.htmlPath); // Wait a bit, then close the launcher window - note to future explorers -
    // I did try and use window events for this (like ready-to-show and others)
    // but they were never fired. Maybe one day you will succeed where I have
    // failed!

    setTimeout(function () {
      bw.show();
      setTimeout(function () {
        getCurrentWindow().close();
      }, 1000);
    }, 500);
  } // Kick off a download retry for the current download manager


  function retryDownload() {
    var dm = getCurrentDownloadManager();
    dm.doDownload();
  }

  return React.createElement("div", {
    className: "LaunchButton"
  }, React.createElement("button", {
    className: "bigButton",
    disabled: !canLaunch,
    onClick: launch
  }, props.online ? 'PLAY TWILIOQUEST' : 'PLAY OFFLINE'), showRetry && props.online ? React.createElement("button", {
    className: "link",
    onClick: retryDownload
  }, "Retry Download") : '');
}

var _default = LaunchButton;
exports["default"] = _default;
//# sourceMappingURL=LaunchButton.js.map