"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/slicedToArray"));

var _LaunchButton = _interopRequireDefault(require("./LaunchButton"));

var _VersionChooser = _interopRequireDefault(require("./VersionChooser"));

// React hooks used in this component
var _React = React,
    useState = _React.useState;

function LauncherControls(props) {
  var _useState = useState("Checking for updates..."),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      status = _useState2[0],
      setStatus = _useState2[1];

  var _useState3 = useState(null),
      _useState4 = (0, _slicedToArray2["default"])(_useState3, 2),
      channelState = _useState4[0],
      setChannelState = _useState4[1];

  return React.createElement("div", {
    className: "LauncherControls"
  }, React.createElement(_LaunchButton["default"], {
    online: props.online,
    channelState: channelState,
    onLaunchStatusUpdate: function onLaunchStatusUpdate(e) {
      return setStatus(e.message);
    }
  }), React.createElement(_VersionChooser["default"], {
    online: props.online,
    onChannelStateUpdated: function onChannelStateUpdated(cs) {
      return setChannelState(cs);
    },
    onError: function onError(e) {
      return setStatus(e.message);
    }
  }), React.createElement("p", {
    className: "status"
  }, status));
}

var _default = LauncherControls;
exports["default"] = _default;
//# sourceMappingURL=LauncherControls.js.map