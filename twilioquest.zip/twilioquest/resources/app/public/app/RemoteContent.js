"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs2/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime-corejs2/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/asyncToGenerator"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/slicedToArray"));

var _querystring = _interopRequireDefault(require("querystring"));

var _config = _interopRequireDefault(require("./config"));

var versionManager = _interopRequireWildcard(require("./version_manager"));

var _React = React,
    useState = _React.useState,
    useEffect = _React.useEffect;
var _window = window,
    localStorage = _window.localStorage;
var LS_FIRST_RUN = 'launcherFirstRun';

function RemoteContent(props) {
  var _useState = useState(false),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      newLauncherAvailable = _useState2[0],
      setNewLauncherAvailable = _useState2[1]; // Check for new launcher version, and take over UI area if one is available


  useEffect(function () {
    (0, _asyncToGenerator2["default"])(
    /*#__PURE__*/
    _regenerator["default"].mark(function _callee() {
      var hasNew;
      return _regenerator["default"].wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return versionManager.hasNewLauncherVersion();

            case 2:
              hasNew = _context.sent;
              setNewLauncherAvailable(hasNew);

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  }, []); // Render embedded iframe when online

  function renderOnline() {
    // Prepare query string parameters for iframe
    var firstRun = localStorage.getItem(LS_FIRST_RUN);

    var qs = _querystring["default"].stringify({
      ts: new Date().getTime(),
      // iframe cache buster
      firstRun: firstRun ? 'false' : 'true'
    }); // Flip the switch on first run


    localStorage.setItem(LS_FIRST_RUN, true);
    return React.createElement("iframe", {
      src: "".concat(_config["default"].appBaseUrl).concat(_config["default"].launcherUrl, "?").concat(qs),
      frameBorder: "0",
      height: "100%",
      width: "100%"
    });
  } // Render a prompt to download the latest TQ launcher version


  function renderLauncherPrompt() {
    return React.createElement("div", {
      className: "launcherPrompt"
    }, "An important update for the TwilioQuest launcher is required.\xA0", React.createElement("a", {
      href: "https://www.twilio.com/quest/download",
      target: "_blank"
    }, "Please download and install it."));
  } // When offline, render the TQ logo


  function renderOffline() {
    return React.createElement("div", {
      className: "localMessage"
    }, React.createElement("img", {
      src: "img/shield.png",
      alt: "TwilioQuest Shield"
    }), React.createElement("h2", null, "No Internet Connection"), React.createElement("p", null, "Go back online to download new TwilioQuest versions or do code challenges that require Internet access."));
  }

  return React.createElement("div", {
    className: "RemoteContent"
  }, newLauncherAvailable ? renderLauncherPrompt() : '', props.online ? renderOnline() : renderOffline());
}

var _default = RemoteContent;
exports["default"] = _default;
//# sourceMappingURL=RemoteContent.js.map