"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _assign = _interopRequireDefault(require("@babel/runtime-corejs2/core-js/object/assign"));

var _electronIsDev = _interopRequireDefault(require("electron-is-dev"));

// Default configuration
var config = {
  appBaseUrl: 'https://twilioquest-prod.firebaseapp.com/quest/next',
  launcherUrl: '/launcher',
  // Firebase config for production - since this is the non-admin SDK intended 
  // for use in browser JS applications, it is safe to store configuration in 
  // version control.
  firebaseConfig: {
    apiKey: 'AIzaSyDI5g9d6XTQtUWT6tPqFNJf171sQ08N-ZA',
    authDomain: 'twilioquest-prod.firebaseapp.com',
    databaseURL: 'https://twilioquest-prod.firebaseio.com',
    projectId: 'twilioquest-prod',
    storageBucket: 'twilioquest-prod.appspot.com',
    messagingSenderId: '397868221836'
  }
}; // Attempt to load local config in the dev environment, if present

if (_electronIsDev["default"]) {
  try {
    var localConfig = require('./local_config')["default"];

    config = (0, _assign["default"])(config, localConfig);
  } catch (e) {
    console.log('Error loading local config:');
    console.log(e);
  }
}

var _default = config;
exports["default"] = _default;
//# sourceMappingURL=index.js.map