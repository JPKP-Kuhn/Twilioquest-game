"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs2/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime-corejs2/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/asyncToGenerator"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/slicedToArray"));

var _assign = _interopRequireDefault(require("@babel/runtime-corejs2/core-js/object/assign"));

var versionManager = _interopRequireWildcard(require("./version_manager"));

var _React = React,
    useState = _React.useState,
    useEffect = _React.useEffect,
    useReducer = _React.useReducer; // Handle channel and version selection logic

function channelStateReducer(state, action) {
  if (action.type === 'selectChannel') {
    var nextState = (0, _assign["default"])({}, state);
    var _action$payload = action.payload,
        channelName = _action$payload.channelName,
        releaseList = _action$payload.releaseList;
    nextState.releaseList = releaseList;
    nextState.currentRelease = releaseList[0]; // Select the correct channel

    state.channelList.forEach(function (c) {
      if (c.name === channelName) {
        nextState.currentChannel = c;
      }
    });
    return nextState;
  } else if (action.type === 'selectVersion') {
    // Select a version
    var _nextState = (0, _assign["default"])({}, state);

    state.releaseList.forEach(function (r) {
      if (r.id === action.payload) {
        _nextState.currentRelease = r;
      }
    });
    return _nextState;
  } else if (action.type === 'initialize') {
    var _action$payload2 = action.payload,
        channelList = _action$payload2.channelList,
        _releaseList = _action$payload2.releaseList;
    return {
      channelList: channelList,
      releaseList: _releaseList,
      currentChannel: channelList[0],
      currentRelease: _releaseList[0]
    };
  } else {
    throw new Error('Unrecognized action type');
  }
}

function VersionChooser(props) {
  var _useState = useState(false),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      showAdvanced = _useState2[0],
      setShowAdvanced = _useState2[1];

  var _useReducer = useReducer(channelStateReducer, null),
      _useReducer2 = (0, _slicedToArray2["default"])(_useReducer, 2),
      channelState = _useReducer2[0],
      dispatch = _useReducer2[1]; // Bubble up channel state to the parent to share with interested parties


  props.onChannelStateUpdated(channelState); // Initialize from version manager

  useEffect(function () {
    (0, _asyncToGenerator2["default"])(
    /*#__PURE__*/
    _regenerator["default"].mark(function _callee() {
      var channelList, channelName, releaseList;
      return _regenerator["default"].wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              if (!channelState) {
                _context.next = 2;
                break;
              }

              return _context.abrupt("return");

            case 2:
              _context.prev = 2;
              _context.next = 5;
              return versionManager.fetchChannels();

            case 5:
              channelList = _context.sent;

              if (!(channelList.length < 1)) {
                _context.next = 8;
                break;
              }

              throw new Error("\n            Channel list is empty, which probably means there was wifi, but\n            no Internet connection.\n          ");

            case 8:
              // Get versions for the default release channel
              channelName = channelList[0].name;
              _context.next = 11;
              return versionManager.fetchReleases(channelName);

            case 11:
              releaseList = _context.sent;
              dispatch({
                type: 'initialize',
                payload: {
                  channelList: channelList,
                  releaseList: releaseList
                }
              });
              _context.next = 19;
              break;

            case 15:
              _context.prev = 15;
              _context.t0 = _context["catch"](2);
              console.log(_context.t0);
              props.onError(new Error(!props.online ? "Can't download initial version list when offline." : "Unable to load TwilioQuest versions :( - relaunch and try again."));

            case 19:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[2, 15]]);
    }))();
  }); // Helper to select a new channel and update as needed

  function selectChannel(_x) {
    return _selectChannel.apply(this, arguments);
  } // Render options for channels


  function _selectChannel() {
    _selectChannel = (0, _asyncToGenerator2["default"])(
    /*#__PURE__*/
    _regenerator["default"].mark(function _callee2(channelName) {
      var releaseList;
      return _regenerator["default"].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return versionManager.fetchReleases(channelName);

            case 3:
              releaseList = _context2.sent;
              dispatch({
                type: 'selectChannel',
                payload: {
                  channelName: channelName,
                  releaseList: releaseList
                }
              });
              _context2.next = 11;
              break;

            case 7:
              _context2.prev = 7;
              _context2.t0 = _context2["catch"](0);
              console.error("Unable to fetch releases for channel ".concat(channelName));
              dispatch({
                type: 'selectChannel',
                payload: {
                  channelName: channelName,
                  releaseList: []
                }
              });

            case 11:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 7]]);
    }));
    return _selectChannel.apply(this, arguments);
  }

  function renderChannels() {
    if (!channelState || !channelState.channelList) {
      return [React.createElement("option", {
        key: "none",
        value: "none"
      }, "None Available")];
    }

    var channelOptions = channelState.channelList.map(function (c) {
      return React.createElement("option", {
        key: c.id,
        value: c.name
      }, c.displayName);
    });
    return channelOptions;
  } // Render options for versions


  function renderVersions() {
    if (!channelState || !channelState.releaseList || channelState.releaseList.length < 1) {
      return [React.createElement("option", {
        key: "none",
        value: "none"
      }, "None Available")];
    }

    var versionOptions = channelState.releaseList.map(function (r) {
      return React.createElement("option", {
        key: r.id,
        value: r.id
      }, r.name);
    });
    return versionOptions;
  } // Render advanced switch option


  function renderAdvancedLink() {
    var versionString = 'None';

    if (props.online && !channelState) {
      versionString = 'Loading...';
    } else if (channelState && channelState.currentRelease) {
      versionString = channelState.currentRelease.name;
    }

    return React.createElement("div", null, "Current Version: ", versionString, React.createElement("button", {
      className: "link",
      onClick: function onClick() {
        return setShowAdvanced(true);
      }
    }, "More >"));
  } // Render advanced chooser UI


  function renderAdvanced() {
    return React.createElement("div", null, React.createElement("select", {
      value: channelState ? channelState.currentChannel.name : '',
      onChange: function onChange(e) {
        return selectChannel(e.target.value);
      }
    }, renderChannels()), React.createElement("select", {
      value: channelState && channelState.currentRelease ? channelState.currentRelease.id : '',
      onChange: function onChange(e) {
        return dispatch({
          type: 'selectVersion',
          payload: e.target.value
        });
      }
    }, renderVersions()), React.createElement("button", {
      className: "link",
      onClick: function onClick() {
        return setShowAdvanced(false);
      }
    }, "Hide"));
  }

  return React.createElement("div", {
    className: "VersionChooser"
  }, showAdvanced ? renderAdvanced() : renderAdvancedLink());
}

var _default = VersionChooser;
exports["default"] = _default;
//# sourceMappingURL=VersionChooser.js.map