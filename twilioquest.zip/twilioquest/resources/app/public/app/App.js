"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs2/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs2/core-js/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs2/helpers/slicedToArray"));

var _electron = require("electron");

var _RemoteContent = _interopRequireDefault(require("./RemoteContent"));

var _LauncherControls = _interopRequireDefault(require("./LauncherControls"));

// React hooks
var _React = React,
    useState = _React.useState,
    useEffect = _React.useEffect; // For remote debugging

console.log('Launcher Version:', _electron.remote.app.getVersion()); // Count the number of clicks (doesn't need to update UI state)

var toolsClickCount = 0;

function App() {
  var _useState = useState(window.navigator.onLine),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      online = _useState2[0],
      setOnline = _useState2[1];

  useEffect(function () {
    // Online/offline event reporting is inconsistent, but the value of 
    // onLine doesn't seem to be - poll this value instead of using the window
    // event
    var online = function online() {
      return setOnline(window.navigator.onLine);
    };

    var interval = setInterval(function () {
      var newVal = window.navigator.onLine;

      if (newVal != online) {
        setOnline(newVal);
      }
    }, 10000); // Unregister handlers when the component is re-rendered

    return function () {
      clearInterval(interval);
    };
  }); // Secret function to open dev tools - shhh!!!

  function tryOpenTools() {
    toolsClickCount++;

    if (toolsClickCount === 10) {
      toolsClickCount = 0;
      console.warn("\n        ************************************************************\n        Danger! Do NOT execute any code given to you by strangers!\n        \n        This is an administrative tool for debugging, and executing\n        code you don't understand here could compromise the security\n        of your computer. Please close this window unless you fully\n        understand what you are doing.\n        ************************************************************\n      ");

      _electron.remote.BrowserWindow.getFocusedWindow().webContents.openDevTools();
    }
  } // If the launcher window is closed, quit the app


  function close() {
    _electron.remote.app.quit();
  }

  return React.createElement("div", {
    className: "App"
  }, React.createElement("div", {
    className: "computer-inner"
  }, React.createElement("div", {
    className: "tl"
  }), React.createElement("div", {
    className: "tm"
  }), React.createElement("div", {
    className: "tr"
  }), React.createElement("div", {
    className: "r"
  }), React.createElement("div", {
    className: "l"
  }), React.createElement("div", {
    className: "botl",
    onClick: function onClick() {
      return tryOpenTools();
    }
  }), React.createElement("div", {
    className: "bm"
  }), React.createElement("div", {
    className: "botr"
  }), React.createElement("div", {
    className: "computer-bg"
  }, React.createElement("h2", {
    className: "window-title"
  }, "TwilioQuest Launcher"), React.createElement(_RemoteContent["default"], {
    online: online
  }), React.createElement(_LauncherControls["default"], {
    online: online
  })), React.createElement("div", {
    className: "close",
    onClick: function onClick() {
      return close();
    }
  }, "\xA0")));
}

var _default = App;
exports["default"] = _default;
//# sourceMappingURL=App.js.map