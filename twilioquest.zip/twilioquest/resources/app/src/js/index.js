import App from './app/App';

ReactDOM.render(<App />, document.getElementById('app'));
